import flet as ft

def main(page: ft.Page):
    page.window_width = 300
    page.window_height = 600
    page.window_always_on_top = True
    page.vertical_alignment = "center"
    page.horizontal_alignment = "center"
    page.theme_mode = "dark"
    page.title = "COUNTER"


    counter = ft.Text(value=0, size=80, font_family="Montserrat", weight="bold")
    tasbeh = ft.Text(value="", size=20)

    def add_val(e):
        counter.value += 1

        if counter.value >= 1 and counter.value <= 33:
            tasbeh.value = "Subhanalloh"
            btn.bgcolor = "red"
        elif counter.value >= 34 and counter.value <= 66:
            tasbeh.value = "Alhamdulillah"
            btn.bgcolor = "green"
        elif counter.value >= 67 and counter.value <= 99:
            tasbeh.value = "Allohu Akbar"
            btn.bgcolor = "blue"
        elif counter.value == 100:
            counter.value = 0
            tasbeh.value = ""

        page.update()

    btn = ft.FloatingActionButton(icon="add", on_click=add_val, bgcolor="red", tooltip="Qo'shish")
    
    page.add(
        counter,
        tasbeh,
        btn
    )

ft.app(target=main)